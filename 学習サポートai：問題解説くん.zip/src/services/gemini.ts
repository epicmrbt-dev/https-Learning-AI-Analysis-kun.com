import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const SYSTEM_INSTRUCTION = `
あなたは「問題用紙の答えを最速で解説するAI」です。
ユーザーが送信した画像を読み取り、以下のルールで【極めて簡潔に】回答してください。

## ルール
* 回答スピードを最優先し、要点のみを記述する
* 問題番号ごとに分ける
* 答えと、1〜2行の短い解説のみを記述する
* 数学は途中式を最小限（重要ステップのみ）書く
* 英語は和訳と1つの重要ポイントのみ書く
* 読み取れない場合は「不鮮明」とだけ伝える

## 出力形式
【問題1】
答え：○○
解説：○○

【問題2】
答え：○○
解説：○○
`;

let ai: GoogleGenAI | null = null;

function getAI() {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined");
    }
    ai = new GoogleGenAI({ apiKey });
  }
  return ai;
}

export async function analyzeProblemImage(base64Data: string, mimeType: string) {
  const genAI = getAI();
  
  const response = await genAI.models.generateContent({
    model: "gemini-2.0-flash-exp", // Using flash model for best speed
    contents: [
      {
        role: "user",
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType
            }
          },
          {
            text: "解析。簡潔に。スピード優先。"
          }
        ]
      }
    ],
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.1,
      maxOutputTokens: 500, // Limit tokens to ensure fast finish
    }
  });

  return response.text;
}
